﻿using System;
using System.Collections.Generic;

namespace HD.EFCore.MySqlGenerator._20180510_205224_123
{
    public partial class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int? Age { get; set; }
    }
}
